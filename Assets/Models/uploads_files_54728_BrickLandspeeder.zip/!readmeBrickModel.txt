Brick Landspeeder (based on the vehicle from "Star Wars")
for use in Poser 5 and above (PC/ Mac)
c 2010 Vanishing Point
by John Hoagland jch@cocs.com

Directions:
Extract the files into the specified folders:
Put the obj file (geometry) into Runtime\Libraries\VP\lego
Put the cr2/ png files (figure) into Runtime\Libraries\Lego Figures
Put the pz2/ png files (poses) into Runtime\Libraries\Poses\Lego Figures


Using the files:
1) Start Poser.
2) Go to the Figures > LEGO Library.
3) Add the model to the scene.

Notes:
1) This model is scaled for use with the Modular Brick Figure, also available at Vanishing Point:
http://www.vanishingpoint.biz/freestuff.asp?ClassificationID=40

1a) To use the pose for the figure:
Select the LEGO figure, not the vehicle.
Go to Poses > Lego Figures.
Apply the pose for "SitIn" (this model).
(If you accidentally apply the pose to the vehicle instead of the figure, nothing will happen.)

2) Although this model is UV-Mapped, no textures are included.
The materials are named according to "brick" color to keep things simpler.

Note for non-Poser users:
Extract the obj and mtl file to any folder and import the obj file into your favorite software program.


-----------------------------------
Vanishing Point... Innovating the 3D World
http://www.vanishingpoint.biz


Usage License:
You are completely free to use this figure in any commercial or non-commercial render, image, or animation.
You may NOT sell or give away any files found in this zip package without express permission.

Although this model is designed to resemble LEGO building bricks, no "bricks" in this model use the LEGO brand name.
LEGO is a copyright of the LEGO company and no endorsement from the LEGO Company has been given.

-----------------------------------
To purchase the Star Wars Trilogy on DVD, go to Amazon.com:
http://www.amazon.com/exec/obidos/ASIN/B00003CXCT/vanishingpo02-20/102-2167267-6218553?creative=125581&camp=2321&link_code=as1

Star Wars, Landspeeder, and all likenesses copyright LucasFilm.