Modular Brick Mini Ambulance Set
for use in Poser 5 and above (PC/ Mac)
c 2010 Vanishing Point
by John Hoagland jch@cocs.com

This set contains three models:
-Mini Ambulance vehicle
-Mini Computer/ Scanner
-Mini Stretcher

Directions:
Extract the files into the specified folders:
Put the obj file (geometry) into Runtime\Libraries\VP\lego
Put the cr2/ png files (figure) into Runtime\Libraries\Lego Figures
Put the pz2/ png files (poses) into Runtime\Libraries\Poses\Lego Figures

Using the files:
1) Start Poser.
2) Go to the Figures > LEGO Library.
3) Add any of the models to the scene.

To place the Brick Figure into the Ambulance or Stretcher:
1) (Add the Brick Figure to the scene and make sure it's selected.)
2) Go to the Pose > LEGO Figures Library and apply the "SitIn" pose to the Brick Figure.
For the Stretcher, apply either the "LayingOnStretcher" or "SitOnStrecher" poses.

Notes:
1) These models are scaled for use with the Modular Brick Figure, also available at Vanishing Point:
http://www.vanishingpoint.biz/freestuff.asp?ClassificationID=40

2) Although these models are UV-Mapped, no textures are included.
The materials are named according to "brick" color to keep things simpler.


-----------------------------------
Vanishing Point... Innovating the 3D World
http://www.vanishingpoint.biz


Usage License:
You are completely free to use this figure in any commercial or non-commercial render, image, or animation.
You may NOT sell or give away any files found in this zip package without express permission.

Although this model is designed to resemble LEGO building bricks, no "bricks" in this model use the LEGO brand name.
LEGO is a copyright of the LEGO company and no endorsement from the LEGO Company has been given.
