Brick Figure
for use in Poser 5 and above (PC/ Mac)
c 2010 Vanishing Point
by John Hoagland jch@cocs.com

Directions:
Extract the files into the specified folders:
Put the obj file (geometry) into Runtime\Libraries\VP\lego
Put the cr2/ png files (figure) into Runtime\Libraries\Lego Figures
Put the pz2/ png files (poses) into Runtime\Libraries\Poses\Lego Figures
Put the gif (templates) and jpg (textures) files into Runtime\Textures\VP\lego
Note: the gif files are not used on the model and are included in case you want to make your own textures.

Using the files:
1) Start Poser.
2) Go to the Figures > LEGO Library.
3) Add the model to the scene.

To hide or show the Rocket Pack:
1) Open the Hierarchy Editor
2) Click the "eye" icon to hide or show the Rocket Pack.
OR
1) Go to the Poses > VP > Lego Figures folder
2) Apply either the FigureHidePack or FigureShowPack to hide or show the Rocket Pack.
These poses do NOT affect any body parts other than the head and pack, which means you can apply this pose at any time and it will not change your pose.

Notes:
1) This model is scaled for use with the other Modular Brick models, available at Vanishing Point:
http://www.vanishingpoint.biz/freestuff.asp?ClassificationID=40

2) Unike the other Modular Brick models, the materials on this model are named according to body part: Head, Torso, Hips, Legs, Arms, and Hands.



-----------------------------------
Vanishing Point... Innovating the 3D World
http://www.vanishingpoint.biz


Usage License:
You are completely free to use this figure in any commercial or non-commercial render, image, or animation.
You may NOT sell or give away any files found in this zip package without express permission.

Although this model is designed to resemble LEGO building bricks, no "bricks" in this model use the LEGO brand name.
LEGO is a copyright of the LEGO company and no endorsement from the LEGO Company has been given.
